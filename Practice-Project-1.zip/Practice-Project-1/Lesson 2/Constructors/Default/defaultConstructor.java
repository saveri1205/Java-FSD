//Java Program to create and call a default constructor  
class defaultConstructor{  
//creating a default constructor  
defaultConstructor(){System.out.println("class is created");}  
//main method  
public static void main(String args[]){  
//calling a default constructor  
defaultConstructor b=new defaultConstructor();  
}  
}  