package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Employee;
import com.dao.EmployeeDAO;

@Service
public class EmployeeService {
	@Autowired
	EmployeeDAO employeeDao;
	
	public Employee findEmployeeById(int id) {
		return employeeDao.getEmployeeDetails(id);
	} 
	
	public List<Employee> findAllEmployees() {
		return employeeDao.getAllEmployeeDetails();
	} 
	
	public Employee storeEmployees(Employee emp) {
		return employeeDao.StoreEmployee(emp);
	} 
}
