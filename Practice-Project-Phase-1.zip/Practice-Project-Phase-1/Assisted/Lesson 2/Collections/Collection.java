import java.util.*;  
class Collection{  
		public static void main(String args[]){  

		ArrayList<String> food=new ArrayList<String>();//Creating arrayList  
		food.add("Pasta");//Adding object in arrayfood  
		food.add("Noodles");  
		food.add("Pizza");  
		food.add("Bread");  
		System.out.println(food);

		LinkedList<String> universities=new LinkedList<String>();//Creating linkedList  
		universities.add("PES");//Adding object in arrayfood  
		universities.add("IIT");  
		universities.add("RV");  
		universities.add("BMS");  
		System.out.println(universities);

		Vector<String> Shapes=new Vector<String>();//Creating Vector 
		Shapes.add("Square");//Adding object in arrayfood  
		Shapes.add("Rectangle");  
		Shapes.add("Triangle");  
		Shapes.add("Circle");  
		System.out.println(Shapes);
		

	}  
}  