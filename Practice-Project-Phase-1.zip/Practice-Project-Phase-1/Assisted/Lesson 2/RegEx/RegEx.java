import java.util.regex.Pattern;
 
// Main class
class RegEx {
 
    // Main driver method
    public static void main(String args[])
    {
 
        
        System.out.println(Pattern.matches("Sav*ri", "Saveri"));
 
        
        System.out.println(Pattern.matches("S*Sav*ri", "Susarla"));
    }
}