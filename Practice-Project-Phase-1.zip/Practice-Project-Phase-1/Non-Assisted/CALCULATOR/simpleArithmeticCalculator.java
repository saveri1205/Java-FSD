import java.util.*;

public class simpleArithmeticCalculator {
		public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		char operator;
		double num1,num2,result;
		
		System.out.println("Enter the First number: "); //asking user to enter the first number
		num1=input.nextDouble();
		System.out.println("Enter the Second number: "); //asking user to enter the second number
		num2=input.nextDouble();
		
		System.out.println("Choose your Operator: (+,-,* or /)"); //asking user to enter the operator
		operator=input.next().charAt(0);
		
		switch(operator) {
		case '+': //To perform the addition of two numbers
			result=num1+num2;
			System.out.println(num1+ "+" +num2+ "=" +result);
			break;
		case '-': //To perform the subtraction of two numbers
			result=num1-num2;
			System.out.println(num1+ "-" +num2+ "=" +result);
			break;
		case '*': //To perform the multiplication of two numbers
			result=num1*num2;
			System.out.println(num1+ "*" +num2+ "=" +result);
			break;
		case '/': //To perform the division of two numbers
			result=num1/num2;
			System.out.println(num1+ "/" +num2+ "=" +result);
			break;
		default:
			System.out.println("You have entered an invalid operator");
			}
		input.close();
		}
}
