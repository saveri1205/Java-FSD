// This class is use to map our json data. 
export class Login {
    constructor(
        public user:string,
        public pass:number){}
}
